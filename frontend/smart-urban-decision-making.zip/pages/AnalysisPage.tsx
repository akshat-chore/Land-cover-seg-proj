import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AnalysisMode, AnalysisResponse } from '../types';
import { uploadImage } from '../services/api';
import MetricsWrapped from '../components/MetricsWrapped';
import Dashboard from '../components/Dashboard';
import { UploadCloud, Loader2, ArrowLeft } from 'lucide-react';

const AnalysisPage: React.FC = () => {
  const { mode: paramMode } = useParams<{ mode: string }>();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Validate mode
  const mode = (paramMode === 'flood' ? 'flood' : 'deficit') as AnalysisMode;

  // State Machine
  const [viewState, setViewState] = useState<'upload' | 'processing' | 'wrapped' | 'dashboard'>('upload');
  const [data, setData] = useState<AnalysisResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setViewState('processing');
    setError(null);

    try {
      // Simulate min loading time for effect
      const start = Date.now();
      const response = await uploadImage(file);
      const duration = Date.now() - start;
      const minDuration = 2000;
      
      if (duration < minDuration) {
        await new Promise(r => setTimeout(r, minDuration - duration));
      }

      setData(response);
      setViewState('wrapped');
    } catch (err: any) {
      setError(err.message || 'Failed to process image');
      setViewState('upload');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        // reuse the logic, manually trigger
        const file = e.dataTransfer.files[0];
        const syntheticEvent = { target: { files: [file] } } as any;
        handleFileSelect(syntheticEvent);
    }
  };

  const handleWrappedComplete = () => {
    setViewState('dashboard');
  };

  const reset = () => {
    setViewState('upload');
    setData(null);
    setError(null);
  };

  // Renders
  if (viewState === 'dashboard' && data && mode) {
    return <Dashboard data={data} mode={mode} onReset={reset} />;
  }

  if (viewState === 'wrapped' && data && mode) {
    return <MetricsWrapped data={data} mode={mode} onComplete={handleWrappedComplete} />;
  }

  return (
    <div className="min-h-screen bg-mntn-dark flex flex-col items-center justify-center p-6 relative">
      
      {/* Background Decor */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-blue-900/10 to-transparent"></div>
      </div>

      <button 
        onClick={() => navigate('/')} 
        className="absolute top-8 left-8 flex items-center gap-2 text-gray-500 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <div className="max-w-xl w-full text-center z-10">
        
        <h1 className="font-serif text-3xl md:text-4xl text-white mb-2">
            {mode === 'flood' ? 'Flood Simulation' : 'Deficit Analysis'}
        </h1>
        <p className="text-gray-400 mb-12">Upload satellite imagery (GeoTIFF, PNG, JPG)</p>

        {viewState === 'processing' ? (
            <div className="bg-mntn-card border border-gray-800 rounded-2xl p-12 flex flex-col items-center justify-center h-80">
                <Loader2 className="w-12 h-12 text-mntn-accent animate-spin mb-6" />
                <h3 className="text-white font-medium text-lg">Processing Imagery</h3>
                <p className="text-gray-500 text-sm mt-2">Running segmentation models...</p>
            </div>
        ) : (
            <div 
                className="group bg-mntn-card border-2 border-dashed border-gray-700 hover:border-mntn-accent hover:bg-white/5 transition-all duration-300 rounded-2xl p-12 flex flex-col items-center justify-center h-80 cursor-pointer relative"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
            >
                <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <UploadCloud className="w-8 h-8 text-mntn-accent" />
                </div>
                <h3 className="text-white font-medium text-lg">Click to Upload</h3>
                <p className="text-gray-500 text-sm mt-2">or drag and drop your file here</p>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileSelect} 
                    className="hidden" 
                    accept="image/*,.tif,.tiff" 
                />
            </div>
        )}

        {error && (
            <div className="mt-6 p-4 bg-red-900/20 border border-red-500/50 text-red-400 rounded-lg text-sm">
                Error: {error}
            </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisPage;