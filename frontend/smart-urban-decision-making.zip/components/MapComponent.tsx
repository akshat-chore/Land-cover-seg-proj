import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { RiskTile } from '../types';

interface MapComponentProps {
  center: [number, number];
  bounds?: [number, number, number, number];
  riskTiles?: RiskTile[];
  floodGif?: string;
  mode: 'deficit' | 'flood';
  tileLayerUrl?: string;
}

const MapComponent: React.FC<MapComponentProps> = ({ 
  center, 
  bounds, 
  riskTiles, 
  floodGif, 
  mode 
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize Map
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapContainerRef.current).setView(center, 14);

      // Base Layers
      const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles © Esri',
        maxZoom: 19
      });
      
      const street = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 19
      });

      satellite.addTo(mapInstanceRef.current);

      L.control.layers({
        "Satellite": satellite,
        "Dark Mode": street
      }).addTo(mapInstanceRef.current);
    }

    const map = mapInstanceRef.current;

    // Cleanup existing layers (simple approach: remove all and redraw)
    map.eachLayer((layer) => {
      if (!(layer instanceof L.TileLayer)) {
        map.removeLayer(layer);
      }
    });

    // Add Bounds
    if (bounds) {
      const southWest = L.latLng(bounds[0], bounds[1]);
      const northEast = L.latLng(bounds[2], bounds[3]);
      const latLngBounds = L.latLngBounds(southWest, northEast);
      
      L.rectangle(latLngBounds, {
        color: '#D4AF37',
        weight: 1,
        fillOpacity: 0.05
      }).addTo(map);
      
      map.fitBounds(latLngBounds);
    }

    // Add Risk Tiles (for Deficit Mode or General Risk)
    if (mode === 'deficit' && riskTiles) {
      riskTiles.forEach(tile => {
        if (tile.lat && tile.lon) {
            let color = '#10B981'; // Low
            if (tile.risk_score > 0.33) color = '#F59E0B'; // Med
            if (tile.risk_score > 0.66) color = '#EF4444'; // High

            L.circleMarker([tile.lat, tile.lon], {
                radius: 6,
                fillColor: color,
                color: '#fff',
                weight: 1,
                opacity: 0.8,
                fillOpacity: 0.6
            }).bindPopup(`
                <div class="font-sans text-sm">
                    <strong>Tile ID:</strong> ${tile.tile_id}<br/>
                    <strong>Score:</strong> ${tile.risk_score.toFixed(2)}<br/>
                    <strong>Priority:</strong> ${tile.priority_level || tile.risk_level}
                </div>
            `).addTo(map);
        }
      });
    }

    // Add Flood Markers (for Flood Mode)
    if (mode === 'flood' && riskTiles) {
         riskTiles.filter(t => t.risk_level === 'high').forEach(tile => {
            if(tile.lat && tile.lon) {
                L.circleMarker([tile.lat, tile.lon], {
                    radius: 8,
                    fillColor: '#3B82F6', // Blue
                    color: '#fff',
                    weight: 2,
                    opacity: 1,
                    fillOpacity: 0.8
                }).bindPopup(`
                    <div class="font-sans text-sm">
                        <strong>Critical Flood Zone</strong><br/>
                        Lat: ${tile.lat.toFixed(4)}, Lon: ${tile.lon.toFixed(4)}
                    </div>
                `).addTo(map);
            }
         });
    }

    // Add Flood GIF Overlay
    if (mode === 'flood' && floodGif && bounds) {
       const southWest = L.latLng(bounds[0], bounds[1]);
       const northEast = L.latLng(bounds[2], bounds[3]);
       const latLngBounds = L.latLngBounds(southWest, northEast);
       const imgUrl = `data:image/gif;base64,${floodGif}`;
       
       L.imageOverlay(imgUrl, latLngBounds, {
           opacity: 0.7,
           interactive: false
       }).addTo(map);
    }

    // Force resize calculation
    setTimeout(() => {
        map.invalidateSize();
    }, 200);

  }, [center, bounds, riskTiles, floodGif, mode]);

  return <div ref={mapContainerRef} className="w-full h-full rounded-lg shadow-2xl z-0" />;
};

export default MapComponent;