import React, { useState, useEffect, useRef } from 'react';
import { AnalysisResponse, AnalysisMode, ReportResponse, RiskTile } from '../types';
import MapComponent from './MapComponent';
import { generateAIReport } from '../services/api';
import { Map, FileText, Download, Activity, AlertTriangle, Layers, Droplets, Eye, Grid } from 'lucide-react';

interface Props {
  data: AnalysisResponse;
  mode: AnalysisMode;
  onReset: () => void;
}

// Sub-component for the Risk Overlay/Heatmap visualization
const RiskOverlay: React.FC<{ 
    overlayBase64: string; 
    riskTiles?: RiskTile[]; 
    maskShape: [number, number]; 
}> = ({ overlayBase64, riskTiles, maskShape }) => {
    const [showHeatmap, setShowHeatmap] = useState(false);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const imgRef = useRef<HTMLImageElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (showHeatmap && canvasRef.current && imgRef.current && riskTiles && maskShape) {
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');
            const img = imgRef.current;
            
            if (!ctx) return;

            // Match canvas size to displayed image size
            canvas.width = img.clientWidth;
            canvas.height = img.clientHeight;

            const [maskH, maskW] = maskShape;
            const scaleX = canvas.width / maskW;
            const scaleY = canvas.height / maskH;

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            riskTiles.forEach(tile => {
                const x = tile.x * scaleX;
                const y = tile.y * scaleY;
                const w = tile.w * scaleX;
                const h = tile.h * scaleY;

                // Color logic based on risk score
                let color = 'rgba(16, 185, 129, 0.55)'; // Green (Low)
                if (tile.risk_score > 0.33) color = 'rgba(245, 158, 11, 0.55)'; // Yellow (Med)
                if (tile.risk_score > 0.66) color = 'rgba(239, 68, 68, 0.55)'; // Red (High)

                ctx.fillStyle = color;
                ctx.fillRect(x, y, w, h);

                if (tile.risk_level === 'high') {
                    ctx.strokeStyle = 'rgba(255,255,255,0.4)';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(x, y, w, h);
                }
            });
        }
    }, [showHeatmap, riskTiles, maskShape]);

    return (
        <div className="flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-serif text-white">Analysis Visualization</h3>
                <div className="flex bg-gray-900 rounded-lg p-1 border border-gray-700">
                    <button 
                        onClick={() => setShowHeatmap(false)}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors ${!showHeatmap ? 'bg-mntn-card text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
                    >
                        <Eye className="w-3 h-3" /> Overlay
                    </button>
                    <button 
                        onClick={() => setShowHeatmap(true)}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors ${showHeatmap ? 'bg-mntn-accent text-mntn-dark shadow-sm' : 'text-gray-400 hover:text-white'}`}
                    >
                        <Grid className="w-3 h-3" /> Risk Map
                    </button>
                </div>
            </div>
            
            <div ref={containerRef} className="relative rounded-lg overflow-hidden border border-gray-800 bg-black flex-grow">
                <img 
                    ref={imgRef}
                    src={overlayBase64} 
                    alt="Overlay" 
                    className={`w-full h-auto object-contain transition-opacity duration-300 ${showHeatmap ? 'opacity-60' : 'opacity-100'}`} 
                    onLoad={() => {
                        // Trigger re-render of canvas if heatmap is active when image loads
                        if(showHeatmap) setShowHeatmap(true); 
                    }}
                />
                <canvas 
                    ref={canvasRef}
                    className={`absolute inset-0 pointer-events-none transition-opacity duration-300 ${showHeatmap ? 'opacity-100' : 'opacity-0'}`}
                />
            </div>
        </div>
    );
};

const Dashboard: React.FC<Props> = ({ data, mode, onReset }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'map' | 'report'>('overview');
  const [report, setReport] = useState<ReportResponse | null>(null);
  const [loadingReport, setLoadingReport] = useState(false);

  const handleGenerateReport = async () => {
    try {
      setLoadingReport(true);
      const res = await generateAIReport(data);
      setReport(res);
      setActiveTab('report');
    } catch (e) {
      console.error(e);
      alert("Failed to generate report");
    } finally {
      setLoadingReport(false);
    }
  };

  const handleDownload = () => {
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analysis_results_${mode}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const StatCard = ({ label, value, sub, icon: Icon, colorClass = "text-white" }: any) => (
    <div className="bg-mntn-card border border-gray-800 p-6 rounded-xl hover:border-mntn-accent/50 transition-colors duration-300 flex flex-col justify-between h-full">
      <div>
        <div className="flex justify-between items-start mb-4">
            <div className={`p-3 rounded-lg bg-white/5 ${colorClass}`}>
                <Icon className="w-6 h-6" />
            </div>
            <div className="w-1.5 h-1.5 rounded-full bg-mntn-accent opacity-50"></div>
        </div>
        <h3 className="text-3xl font-bold text-white font-sans mb-1">{value}</h3>
        <p className="text-gray-400 text-sm font-medium uppercase tracking-wider">{label}</p>
      </div>
      {sub && <p className="text-xs text-gray-500 mt-4 border-t border-gray-800 pt-3">{sub}</p>}
    </div>
  );

  return (
    <div className="min-h-screen bg-mntn-dark text-white p-4 md:p-8 animate-in fade-in duration-700">
      
      {/* Header */}
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-end mb-10 border-b border-gray-800 pb-6">
        <div>
            <h2 className="text-mntn-accent font-serif text-sm uppercase tracking-widest mb-2">MNTN Intelligence</h2>
            <h1 className="text-4xl md:text-5xl font-bold font-serif">
                {mode === 'flood' ? 'Flood Risk Analysis' : 'Infrastructure Equity'}
            </h1>
        </div>
        <div className="flex gap-4 mt-6 md:mt-0 flex-wrap">
            <button onClick={onReset} className="px-6 py-2 rounded-full border border-gray-700 hover:bg-gray-800 transition-colors text-sm">
                New Analysis
            </button>
            <button 
                onClick={handleDownload}
                className="px-6 py-2 rounded-full border border-gray-700 hover:bg-gray-800 transition-colors text-sm flex items-center gap-2"
            >
                <Download className="w-4 h-4" /> Export Data
            </button>
            <button 
                onClick={handleGenerateReport} 
                disabled={loadingReport}
                className="px-6 py-2 rounded-full bg-mntn-accent text-mntn-dark font-bold hover:bg-white transition-colors text-sm disabled:opacity-50"
            >
                {loadingReport ? 'Generating AI Report...' : 'Generate AI Report'}
            </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto mb-8 flex gap-8 border-b border-gray-800 text-gray-400 overflow-x-auto">
        <button 
            onClick={() => setActiveTab('overview')}
            className={`pb-4 whitespace-nowrap transition-colors ${activeTab === 'overview' ? 'text-mntn-accent border-b-2 border-mntn-accent' : 'hover:text-white'}`}
        >
            Full Analysis Report
        </button>
        <button 
            onClick={() => setActiveTab('map')}
            className={`pb-4 whitespace-nowrap transition-colors ${activeTab === 'map' ? 'text-mntn-accent border-b-2 border-mntn-accent' : 'hover:text-white'}`}
        >
            Interactive Map
        </button>
        <button 
            onClick={() => setActiveTab('report')}
            className={`pb-4 whitespace-nowrap transition-colors ${activeTab === 'report' ? 'text-mntn-accent border-b-2 border-mntn-accent' : 'hover:text-white'}`}
        >
            AI Strategy Report
        </button>
      </div>

      <main className="max-w-7xl mx-auto min-h-[600px]">
        
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
            <div className="space-y-8">
                
                {/* 1. Top Level Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard 
                        label="Inference Time" 
                        value={`${(data.inference_time_ms / 1000).toFixed(2)}s`} 
                        icon={Activity} 
                        sub="End-to-end processing latency"
                        colorClass="text-blue-400"
                    />
                     <StatCard 
                        label="Classes Detected" 
                        value={data.unique_classes.length} 
                        icon={Layers} 
                        sub={data.unique_classes.join(', ')}
                        colorClass="text-purple-400"
                    />
                    {mode === 'flood' ? (
                        <>
                            <StatCard 
                                label="Flooded Structures" 
                                value={data.flood_metrics?.flooded_buildings?.toLocaleString() || 0} 
                                icon={Droplets} 
                                sub={`Impact Ratio: ${(data.flood_metrics?.impact_ratio || 0).toFixed(1)}%`}
                                colorClass="text-blue-500"
                            />
                            <StatCard 
                                label="Risk Status" 
                                value={data.flood_metrics?.status || 'Active'} 
                                icon={AlertTriangle} 
                                sub="Simulation Status"
                                colorClass="text-red-500"
                            />
                        </>
                    ) : (
                        <>
                            <StatCard 
                                label="Deficit Score" 
                                value={data.equity_summary?.mean_deficit_score?.toFixed(2) || 'N/A'} 
                                icon={AlertTriangle} 
                                sub="Mean Infrastructure Deficit"
                                colorClass="text-orange-500"
                            />
                            <StatCard 
                                label="Urgent Zones" 
                                value={data.equity_summary?.urgent_tiles || 0} 
                                icon={AlertTriangle} 
                                sub="Requiring immediate action"
                                colorClass="text-red-500"
                            />
                        </>
                    )}
                </div>

                {/* 2. Visualizations Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-6">
                        <h3 className="text-lg font-serif mb-4 text-white">Segmentation Mask</h3>
                        <div className="rounded-lg overflow-hidden border border-gray-800 bg-black">
                             <img src={data.mask_base64} alt="Segmentation Mask" className="w-full h-auto" />
                        </div>
                    </div>
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-6">
                        <RiskOverlay 
                            overlayBase64={data.overlay_base64} 
                            riskTiles={data.risk_tiles} 
                            maskShape={data.mask_shape} 
                        />
                    </div>
                </div>

                {/* 3. Detailed Data Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Urban Risk Profile */}
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-6">
                        <h3 className="text-lg font-serif mb-4 text-mntn-accent">Urban Risk Profile</h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">Mean Risk Score</span>
                                <span className="text-white font-bold">{data.risk_summary?.mean_risk?.toFixed(3) || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">High-Risk Tiles</span>
                                <span className="text-white font-bold">{data.risk_summary?.high_risk_tile_pct}%</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">Buildings Near Water</span>
                                <span className="text-white font-bold">{data.risk_summary?.buildings_near_water_pct}%</span>
                            </div>
                            <div className="flex justify-between items-center pt-2">
                                <span className="text-gray-400 text-sm">Flags</span>
                                <span className="text-xs bg-red-900/30 text-red-400 px-2 py-1 rounded">
                                    {(data.risk_flags && data.risk_flags.length > 0) ? data.risk_flags.join(', ') : 'None'}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Infrastructure Equity Breakdown */}
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-6">
                        <h3 className="text-lg font-serif mb-4 text-mntn-accent">Equity Breakdown</h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">Total Analyzed Tiles</span>
                                <span className="text-white font-bold">{data.equity_summary?.total_tiles}</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">Urgent Priority</span>
                                <span className="text-red-400 font-bold">{data.equity_summary?.urgent_tiles || data.equity_summary?.num_urgent}</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-400 text-sm">Important Priority</span>
                                <span className="text-orange-400 font-bold">{data.equity_summary?.important_tiles}</span>
                            </div>
                             <div className="flex justify-between items-center pt-2">
                                <span className="text-gray-400 text-sm">Adequate Priority</span>
                                <span className="text-green-400 font-bold">{data.equity_summary?.adequate_tiles}</span>
                            </div>
                        </div>
                    </div>

                    {/* Flood Specifics (Only if Flood Mode) or Extra Stats */}
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-6">
                         <h3 className="text-lg font-serif mb-4 text-mntn-accent">
                             {mode === 'flood' ? 'Flood Simulation Stats' : 'Image Metadata'}
                         </h3>
                         <div className="space-y-4">
                            {mode === 'flood' ? (
                                <>
                                    <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                        <span className="text-gray-400 text-sm">Total Buildings</span>
                                        <span className="text-white font-bold">{data.flood_metrics?.total_buildings?.toLocaleString()}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                        <span className="text-gray-400 text-sm">Impact Ratio</span>
                                        <span className="text-blue-400 font-bold">{(data.flood_metrics?.impact_ratio || 0).toFixed(1)}%</span>
                                    </div>
                                    <div className="flex justify-between items-center pt-2">
                                        <span className="text-gray-400 text-sm">Simulation Status</span>
                                        <span className="text-white font-bold">{data.flood_metrics?.status}</span>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                        <span className="text-gray-400 text-sm">Image Width</span>
                                        <span className="text-white font-bold">{data.image_shape[1]}px</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                        <span className="text-gray-400 text-sm">Image Height</span>
                                        <span className="text-white font-bold">{data.image_shape[0]}px</span>
                                    </div>
                                     <div className="flex justify-between items-center pt-2">
                                        <span className="text-gray-400 text-sm">Channels</span>
                                        <span className="text-white font-bold">{data.image_shape[2]}</span>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                </div>

                {/* 4. Disaster Response Plan (New Section) */}
                {data.response_plan && data.response_plan.length > 0 && (
                    <div className="bg-mntn-card border border-gray-800 rounded-xl p-8">
                        <div className="flex items-center gap-3 mb-6">
                             <div className="bg-mntn-accent/10 p-2 rounded-lg">
                                 <AlertTriangle className="w-6 h-6 text-mntn-accent" />
                             </div>
                             <h3 className="text-xl font-serif text-white">Disaster Response Deployment Plan</h3>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="border-b border-gray-700 text-gray-400 text-xs uppercase tracking-wider">
                                        <th className="py-3 pl-4">Tile ID</th>
                                        <th className="py-3">Priority</th>
                                        <th className="py-3">Risk Level</th>
                                        <th className="py-3">Action Window</th>
                                        <th className="py-3">Recommended Action</th>
                                        <th className="py-3">Location</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data.response_plan.slice(0, 8).map((item, idx) => (
                                        <tr key={idx} className="border-b border-gray-800 last:border-0 hover:bg-white/5 transition-colors text-sm">
                                            <td className="py-4 pl-4 font-mono text-gray-400">{item.tile_id}</td>
                                            <td className="py-4">
                                                <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                                                    item.priority === 'urgent' ? 'bg-red-500/20 text-red-400' :
                                                    item.priority === 'important' ? 'bg-orange-500/20 text-orange-400' :
                                                    'bg-green-500/20 text-green-400'
                                                }`}>
                                                    {item.priority}
                                                </span>
                                            </td>
                                            <td className="py-4 text-gray-300 capitalize">{item.risk_level}</td>
                                            <td className="py-4 text-white font-medium">{item.recommended_window}</td>
                                            <td className="py-4 text-gray-300">{item.recommended_action}</td>
                                            <td className="py-4 text-gray-500 text-xs">
                                                {item.lat?.toFixed(4)}, {item.lon?.toFixed(4)}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {data.response_plan.length > 8 && (
                                <p className="text-center text-xs text-gray-500 mt-4">Showing top 8 priority tasks of {data.response_plan.length}</p>
                            )}
                        </div>
                    </div>
                )}

                {/* 5. Priority Zones Table */}
                <div className="bg-mntn-card border border-gray-800 rounded-xl p-8">
                     <h3 className="text-xl font-serif mb-6 text-white">
                        {mode === 'flood' ? 'Critical Impact Zones' : 'High Deficit Areas'}
                     </h3>
                     <div className="overflow-x-auto max-h-96 custom-scrollbar">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="border-b border-gray-700 text-gray-400 text-sm uppercase sticky top-0 bg-mntn-card z-10">
                                    <th className="py-3 pl-4">Tile ID</th>
                                    <th className="py-3">Risk Score</th>
                                    <th className="py-3">Coordinates</th>
                                    <th className="py-3">Status</th>
                                    <th className="py-3">Metrics (Bldg | Road | Green)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.risk_tiles?.slice(0, 10).map((tile, i) => (
                                    <tr key={i} className="border-b border-gray-800 last:border-0 hover:bg-white/5 transition-colors text-sm">
                                        <td className="py-4 pl-4 font-medium text-white font-mono">{tile.tile_id}</td>
                                        <td className="py-4">
                                            <span className={`px-2 py-1 rounded text-xs font-bold ${
                                                tile.risk_score > 0.6 ? 'bg-red-500/20 text-red-400' : 
                                                tile.risk_score > 0.3 ? 'bg-orange-500/20 text-orange-400' : 'bg-green-500/20 text-green-400'
                                            }`}>
                                                {tile.risk_score.toFixed(3)}
                                            </span>
                                        </td>
                                        <td className="py-4 text-gray-300 font-mono text-xs">
                                            {tile.lat?.toFixed(5)}, {tile.lon?.toFixed(5)}
                                        </td>
                                        <td className="py-4 text-gray-300 capitalize">
                                            {tile.priority_level || tile.risk_level || 'Normal'}
                                        </td>
                                        <td className="py-4 text-gray-400 text-xs">
                                            {tile.building_density_pct?.toFixed(1)}% | {tile.road_coverage_pct?.toFixed(1)}% | {tile.green_space_pct?.toFixed(1)}%
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <p className="text-xs text-gray-500 mt-4 text-center">Showing top 10 most critical zones</p>
                     </div>
                </div>

                {/* 6. Land Cover Statistics */}
                <div className="bg-mntn-card border border-gray-800 rounded-xl p-8">
                     <h3 className="text-xl font-serif mb-6 text-white">Land Cover Breakdown</h3>
                     <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="border-b border-gray-700 text-gray-400 text-sm uppercase">
                                    <th className="py-3 pl-4">Class Name</th>
                                    <th className="py-3">Pixel Count</th>
                                    <th className="py-3">Coverage (%)</th>
                                    <th className="py-3">Area (km²)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Object.keys(data.class_statistics.per_class_pixels).map((cls) => (
                                    <tr key={cls} className="border-b border-gray-800 last:border-0 hover:bg-white/5 transition-colors text-sm">
                                        <td className="py-4 pl-4 font-medium text-white capitalize flex items-center gap-2">
                                            <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                                            {cls}
                                        </td>
                                        <td className="py-4 text-gray-300 font-mono">
                                            {data.class_statistics.per_class_pixels[cls].toLocaleString()}
                                        </td>
                                        <td className="py-4 text-gray-300 font-mono">
                                            {data.class_statistics.per_class_percentages[cls]}%
                                        </td>
                                        <td className="py-4 text-gray-300 font-mono">
                                            {data.class_statistics.per_class_area_km2[cls]}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </div>
                </div>

            </div>
        )}

        {/* MAP TAB */}
        {activeTab === 'map' && (
            <div className="h-[750px] w-full bg-gray-900 rounded-xl overflow-hidden relative border border-gray-800 shadow-2xl">
                {data.has_geo ? (
                    <MapComponent 
                        center={data.geo_center || [52.0, 19.0]}
                        bounds={data.geo_bounds}
                        riskTiles={data.risk_tiles}
                        floodGif={data.flood_gif_base64}
                        mode={mode}
                    />
                ) : (
                    <div className="absolute inset-0 flex items-center justify-center flex-col text-gray-500">
                        <AlertTriangle className="w-12 h-12 mb-4" />
                        <p>No geographic metadata found in this image.</p>
                    </div>
                )}
            </div>
        )}

        {/* REPORT TAB */}
        {activeTab === 'report' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {!report && !loadingReport && (
                    <div className="col-span-3 text-center py-24 text-gray-500 bg-mntn-card rounded-xl border border-gray-800">
                        <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <h3 className="text-xl font-medium text-white mb-2">AI Strategy Report</h3>
                        <p className="max-w-md mx-auto">Generate a comprehensive narrative report analyzing urban planning needs and disaster management strategies based on this satellite data.</p>
                        <button 
                            onClick={handleGenerateReport}
                            className="mt-6 px-8 py-3 bg-mntn-accent text-mntn-dark font-bold rounded-full hover:bg-white transition-colors"
                        >
                            Generate Report
                        </button>
                    </div>
                )}

                {loadingReport && (
                     <div className="col-span-3 text-center py-32 text-gray-500">
                        <div className="animate-spin w-10 h-10 border-2 border-mntn-accent border-t-transparent rounded-full mx-auto mb-6"></div>
                        <p className="text-lg animate-pulse">Consulting AI Models...</p>
                        <p className="text-sm mt-2">Analyzing {data.unique_classes.length} land cover classes and {data.risk_tiles?.length} risk zones.</p>
                    </div>
                )}

                {report && report.success && report.report && (
                    <>
                        <div className="col-span-3 bg-gradient-to-r from-mntn-card to-gray-900 border-l-4 border-mntn-accent p-8 rounded-r-xl shadow-lg">
                            <h3 className="font-serif text-2xl mb-4 text-white flex items-center gap-3">
                                <FileText className="text-mntn-accent" /> Executive Summary
                            </h3>
                            <p className="text-gray-200 leading-relaxed text-lg font-light">{report.report.executive_summary}</p>
                        </div>

                        <div className="bg-mntn-card border border-gray-800 p-8 rounded-xl">
                            <h4 className="font-serif text-xl mb-6 text-mntn-accent border-b border-gray-800 pb-4">Urban Planning</h4>
                             <ul className="space-y-4 text-gray-300">
                                {Array.isArray(report.report.urban_planning) 
                                    ? report.report.urban_planning.map((item, i) => (
                                        <li key={i} className="flex gap-3 items-start">
                                            <span className="text-mntn-accent text-xl leading-none mt-1">•</span> 
                                            <span className="leading-relaxed">{item}</span>
                                        </li>
                                    ))
                                    : <p>{report.report.urban_planning}</p>
                                }
                            </ul>
                        </div>

                        <div className="bg-mntn-card border border-gray-800 p-8 rounded-xl">
                            <h4 className="font-serif text-xl mb-6 text-mntn-accent border-b border-gray-800 pb-4">Disaster Management</h4>
                             <ul className="space-y-4 text-gray-300">
                                {Array.isArray(report.report.disaster_management) 
                                    ? report.report.disaster_management.map((item, i) => (
                                        <li key={i} className="flex gap-3 items-start">
                                            <span className="text-mntn-accent text-xl leading-none mt-1">•</span> 
                                            <span className="leading-relaxed">{item}</span>
                                        </li>
                                    ))
                                    : <p>{report.report.disaster_management}</p>
                                }
                            </ul>
                        </div>

                        <div className="bg-mntn-card border border-gray-800 p-8 rounded-xl">
                            <h4 className="font-serif text-xl mb-6 text-mntn-accent border-b border-gray-800 pb-4">Strategic Recommendations</h4>
                             <ul className="space-y-4 text-gray-300">
                                {report.report.recommendations?.model_improvements?.map((item, i) => (
                                    <li key={i} className="flex gap-3 items-start">
                                        <span className="text-mntn-accent mt-1">→</span> 
                                        <span className="leading-relaxed">{item}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </>
                )}
            </div>
        )}

      </main>

        <footer className="max-w-7xl mx-auto mt-20 pt-8 border-t border-gray-800 text-center pb-8">
            <p className="text-gray-600 text-[10px] tracking-[0.2em] uppercase">
                Generated by MNTN Intelligence System
            </p>
        </footer>
    </div>
  );
};

export default Dashboard;